
#ifndef _LAMBDA_EMA_ALPHA_
#define _LAMBDA_EMA_ALPHA_ 0.02
#endif

#ifndef _MASS_EMA_ALPHA_
#define _MASS_EMA_ALPHA_ 0.01
#endif

#ifndef _MASS_MIN_SAMPLES_ 
#define _MASS_MIN_SAMPLES_ 100
#endif

